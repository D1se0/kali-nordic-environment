#!/usr/bin/env bash
# cpu.sh — % de CPU global desde /proc/stat (cálculo real, sin top)
set -u
. "$(dirname "${BASH_SOURCE:-$0}")/lib.sh"
read -r _ u1 n1 s1 i1 _ < /proc/stat
sleep "${NORDIC_CPU_SAMPLE:-2}"
read -r _ u2 n2 s2 i2 _ < /proc/stat
used=$(( (u2 + n2 + s2) - (u1 + n1 + s1) ))
idle=$(( i2 - i1 ))
tot=$(( used + idle ))
if [ "$tot" -le 0 ]; then pc=0; else pc=$(( used * 100 / tot )); fi
if [ "$pc" -ge 85 ]; then nc="$N_RED"
elif [ "$pc" -ge 70 ]; then nc="$N_YEL"
else                          nc="$N_FG"; fi
printf '%%{B%s} %%{F%s}   %%{F%s}%s%%%%{F-} %%{B-}' "$N_BG" "$N_FROST" "$nc" "$pc"
