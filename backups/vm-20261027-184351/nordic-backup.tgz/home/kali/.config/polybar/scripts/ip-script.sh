#!/usr/bin/env bash
# ip-script.sh — IP local de la interfaz principal (eth0/ens33/enp*); 'sin red' si no hay
set -u
pill() { printf '%%{B#883B4252} %s %%{B-}' "$1"; }
IFS=' '
IFS=' '
iface=""
ip4=""
for f in eth0 ens33 enp*; do
  case "$f" in *'*') continue ;; esac
  v=$(ip -4 -o addr show dev "$f" 2>/dev/null | awk 'NR==1{print $4; exit}')
  if [ -n "$v" ]; then iface="$f"; ip4="${v%%/*}"; break; fi
done
# fallback: cualquier interfaz no-lo con IPv4
if [ -z "$ip4" ]; then
  iface=$(ip -4 -o addr show 2>/dev/null | awk '$2!="lo"{print $2; exit}')
  ip4=$(ip -4 -o addr show dev "$iface" 2>/dev/null | awk 'NR==1{print $4}' | cut -d/ -f1)
fi
if [ -n "$ip4" ]; then
  echo "$(pill "  $ip4")  "
else
  echo "$(pill '  sin red')  "
fi
