#!/usr/bin/env bash
# logo.sh — píldora del logo Kali (clic → rofi lanzador)
echo "%{B#88C0D0}%{F#2E3440}    KALI    %{B-}"
