#!/usr/bin/env bash
# target.sh — módulo TARGET (ipc-hook)
# Estados: empty → 'No target' atenuado · set →  TARGET
# polybar-msg hook target 1|2 dispara el cambio instantáneo (settarget lo hace).
set -u
. "$(dirname "${BASH_SOURCE:-$0}")/lib.sh"
state_file="${NORDIC_TARGET_FILE:-$( [ ${EUID:-$(id -u)} -eq 0 ] && echo /run/nordic/target 2>/dev/null || echo "$HOME/.cache/nordic/target" )}"
read -r line < "$state_file" 2>/dev/null
ip=${line%%|*}
name=${line#*|}
[ -n "$name" ] || name=""

if [ -z "$ip" ]; then
  printf '%%{B%s} %%{F%s}  No target  %%{B-}' "$N_BG" "$N_MUT"
else
  label="${name:-$ip}"
  label="${label:0:24}"
  pill_act " $label"
fi
