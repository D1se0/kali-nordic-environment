#!/usr/bin/env bash
# title.sh — píldora central del título de la ventana activa
set -u
. "$(dirname "${BASH_SOURCE:-$0}")/lib.sh"

t=$(bspc query -T -n focused 2>/dev/null | jq -r '.title // empty' 2>/dev/null)
[ -n "$t" ] || t="—"
t="${t:0:60}"
echo "%{B${N_BG_ACT}}%{F${N_FG}}   $t   %{B-}"
