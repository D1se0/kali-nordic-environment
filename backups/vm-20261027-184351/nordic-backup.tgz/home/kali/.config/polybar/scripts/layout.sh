#!/usr/bin/env bash
# layout.sh — píldora del layout actual (tiled/monocle/fullscreen/flotante)
set -u
. "$(dirname "${BASH_SOURCE:-$0}")/lib.sh"

lay=$(bspc query -T -d focused 2>/dev/null | jq -r '.layout // "long"' 2>/dev/null)
node=$(bspc query -T -n focused 2>/dev/null | jq -r '.state // empty' 2>/dev/null)

case "$node" in
    fullscreen) pill " fullscreen" ;;
    floating)   pill " flotante" ;;
    *)
        case "$lay" in
            monocle) pill " monocle" ;;
            spiral)  pill " spiral" ;;
            *)       pill " tiled" ;;
        esac
        ;;
esac
