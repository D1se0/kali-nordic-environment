#!/usr/bin/env bash
# vpn.sh —  detección de VPN (tun*/wg*/tailscale*/ppp*) con IP
set -u
. "$(dirname "${BASH_SOURCE:-$0}")/lib.sh"
dev="$(ip -o link 2>/dev/null | awk -F': ' '{print $2}' | grep -Eo '^(tun|wg|tailscale|ppp)[a-zA-Z0-9]*' | head -1)"
if [ -n "$dev" ]; then
  ip_v="$(ip -4 -o addr show dev "$dev" 2>/dev/null | awk 'NR==1{print $4}' | cut -d/ -f1)"
  [ -n "$ip_v" ] || ip_v="$(ip -6 -o addr show dev "$dev" scope global 2>/dev/null | awk 'NR==1{print $4}' | cut -d/ -f1)"
  if [ -n "$ip_v" ]; then
    case "$ip_v" in
      10.10.*) et=' · HTB' ;;
      *)       et='' ;;
    esac
    printf '%%{B%s} %%{F%s} VPN %s%s  %%{B-}' "$N_BG" "$N_GRN" "$ip_v" "$et"
  else
    printf '%%{B%s} %%{F%s} VPN up  %%{B-}' "$N_BG" "$N_GRN"
  fi
else
  printf '%%{B%s} %%{F%s} VPN off  %%{B-}' "$N_BG" "$N_MUT"
fi
