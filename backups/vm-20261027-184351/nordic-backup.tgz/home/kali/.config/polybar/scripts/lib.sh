# lib.sh — helpers de diseño para los módulos polybar kali-nordic
# Píldora uniforme: bg translúcido NORD1 · icono Nerd Font Frost · texto Snow Storm
# padding compacto: el module-margin (config.ini) da el aire ENTRE píldoras.

N_BG='#883B4252'      # bg de píldora (translúcido)
N_BG_ACT='#88434C5E'  # píldora activa (un punto más clara)
N_FG='#D8DEE9'
N_MUT='#767F97'       # atenuado pero legible sobre dark
N_FROST='#88C0D0'
N_FROST2='#81A1C1'
N_RED='#BF616A'
N_YEL='#EBCB8B'
N_GRN='#A3BE8C'

# pill <texto>            → píldora simple:  texto  (icono Frost ya dentro del texto)
# pill_full <icon><color> <texto> <bgefect> → control total
pill() {              # $1=icono+texto con colores ya aplicados
    printf '%%{B%s} %s%%{F%s} %s %%{B-}' "$N_BG" "$1" "$N_FG" "${2:-}"
}

pill_act() {          # píldora resaltada (ej: target set, ws activo)
    printf '%%{B%s} %s%%{F%s} %s %%{B-}' "$N_BG_ACT" "$1" "$N_FG" "${2:-}"
}
