#!/usr/bin/env bash
# ram.sh — ' 7% · 0.7G ' desde /proc/meminfo
set -u
. "$(dirname "${BASH_SOURCE:-$0}")/lib.sh"
total=$(awk '/MemTotal/{print $2}' /proc/meminfo)
avail=$(awk '/MemAvailable/{print $2}' /proc/meminfo)
if [ -z "$total" ] || [ -z "$avail" ] || [ "$total" -eq 0 ]; then
  printf '%%{B%s} %%{F%s}    --  %%{B-}' "$N_BG" "$N_MUT"; exit 0
fi
used=$(( total - avail ))
pc=$(( used * 100 / total ))
ush=$(awk -v u="$used" 'BEGIN{printf "%.1f", u/1048576}')
if [ "$pc" -ge 85 ]; then nc="$N_RED"
elif [ "$pc" -ge 75 ]; then nc="$N_YEL"
else                          nc="$N_FG"; fi
printf '%%{B%s} %%{F%s}   %%{F%s}%s%%{F-} · %sG %%{B-}' "$N_BG" "$N_FROST" "$nc" "$pc" "$ush"
