#!/usr/bin/env bash
# power.sh — botón de energía: icono power en píldora roja (clic → nordic-power)
echo "%{B#88BF616A}%{F#ECEFF4}    %{B-}"
