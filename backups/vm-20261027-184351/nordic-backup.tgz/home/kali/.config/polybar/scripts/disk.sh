#!/usr/bin/env bash
# disk.sh — ' / 16/78 23% ' compacto
set -u
. "$(dirname "${BASH_SOURCE:-$0}")/lib.sh"
read -r _ uszy usdd ttl pc < <(df -k / 2>/dev/null | awk 'NR==2{print $1, $3, $4, $2, $5}')
if [ -z "${ttl:-}" ] || [ "${ttl:-0}" -eq 0 ]; then
  printf '%%{B%s} %%{F%s}    --  %%{B-}' "$N_BG" "$N_MUT"; exit 0
fi
ugb=$(awk -v u="$uszy" 'BEGIN{printf "%.0f", u/1048576}')
tgb=$(awk -v t="$ttl" 'BEGIN{printf "%.0f", t/1048576}')
pc="${pc%\%}"
if [ "$pc" -ge 90 ]; then nc="$N_RED"
elif [ "$pc" -ge 80 ]; then nc="$N_YEL"
else                          nc="$N_FG"; fi
printf '%%{B%s} %%{F%s} /  %%{F%s}%s/%s %s%%%%{F-}  %%{B-}' "$N_BG" "$N_FROST" "$nc" "$ugb" "$tgb" "$pc"
