#!/usr/bin/env bash
# workspaces.sh — escritorios bspwm con iconos + estados (tail sobre bspc subscribe)
# Uso: stream | raw | click N
set -u
export PATH="$HOME/.local/bin:$PATH"
. "$(dirname "${BASH_SOURCE:-$0}")/lib.sh"

readonly WS_ICONS=(
    $'\uf120'  # terminal
    $'\uf269'  # web
    $'\uf121'  # código
    $'\uf02d'  # notas
    $'\uf1eb'  # red
    $'\uf086'  # chat
    $'\uf013'  # misc
    $'\uf0ad'  # tools
    $'\uf005'  # extra
)

in_list() { case " $2 " in *" $1 "*) return 0 ;; *) return 1 ;; esac; }

# ws <nombre> <icono> [<estado>]
ws() {
    local icon="$1" name="$2" state="${3:-}"
    local mark
    if [[ $state == focused ]]; then
        mark="%{B#88C0D0}%{F#2E3440} ${icon} %{B-}%{F-} "
    elif [[ $state == urgent ]]; then
        mark="%{F#EBCB8B} ${icon} %{F-} "
    elif [[ $state == occupied ]]; then
        mark="%{F#8FBCBB} ${icon} %{F-} "
    else
        mark="%{F#767F97} ${icon} %{F-} "
    fi
    printf '%%{A1:"'"$HOME"'/..config/polybar/scripts/workspaces.sh click %s:}%s%%{A} ' "$name" "$mark"
}

state_line() {
    local names focused occupied urgent out='' n icon i=0
    names=$(bspc query -D --names 2>/dev/null | tr '\n' ' ' | xargs)
    if [[ -z $names ]]; then
        echo ""
        return 0
    fi
    focused=$(bspc query -D -d focused --names 2>/dev/null | head -1)
    occupied=$(bspc query -D -d .occupied --names 2>/dev/null | tr '\n' ' ' | xargs)
    urgent=$(bspc query -D -d .urgent --names 2>/dev/null | tr '\n' ' ' | xargs)

    for n in $names; do
        icon="${WS_ICONS[i]:-}"; i=$((i + 1))
        state=''
        in_list "$n" "$occupied" && state=occupied
        in_list "$n" "$urgent" && state=urgent
        [[ $n == "$focused" ]] && state=focused
        out+="$(ws "$icon" "$n" "$state")"
    done
    echo "$out"
}

case "${1:-}" in
    stream)
        state_line
        bspc subscribe 2>/dev/null | while read -r _; do state_line; done
        ;;
    raw|'') state_line ;;
    click)  bspc desktop -f "$2" 2>/dev/null ;;
esac
